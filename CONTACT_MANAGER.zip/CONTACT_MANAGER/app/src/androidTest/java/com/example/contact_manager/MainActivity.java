package com.example.contact_manager;

public class MainActivity extends AppCompatActivity {
    EditText etName, etPhone;
    Button btnAdd;
    ListView lvContacts;
    DatabaseHelper db;
    ArrayAdapter<String> adapter;
    List<Contact> contactList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DatabaseHelper(this);

        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        btnAdd = findViewById(R.id.btnAdd);
        lvContacts = findViewById(R.id.lvContacts);

        loadContacts();

        btnAdd.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String phone = etPhone.getText().toString();
            db.addContact(new Contact(0, name, phone));
            loadContacts();
        });

        lvContacts.setOnItemClickListener((parent, view, position, id) -> {
            Contact c = contactList.get(position);
            db.deleteContact(c.getId());
            loadContacts();
        });
    }

    private void loadContacts() {
        contactList = db.getAllContacts();
        List<String> names = new ArrayList<>();
        for (Contact c : contactList) {
            names.add(c.getName() + " - " + c.getPhone());
        }
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, names);
        lvContacts.setAdapter(adapter);
    }
}